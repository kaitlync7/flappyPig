
// AP Computer Science A Final Project: Flappy Bird
// Kaitlyn, Maya, Sarah, Tvisha
// June 11, 2024

// imports
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;

public class MyFrame extends JFrame implements KeyListener {
  private static final ReplitDatabase db = new ReplitDatabase();
  
  // importing the images
  JLabel background1 = new JLabel(new ImageIcon("backdrop.jpg"));
  JLabel background2 = new JLabel();
  JLabel pig = new JLabel(new ImageIcon("fancyflyingpig.png"));
  JLabel upPipe = new JLabel(new ImageIcon("fancyUpPipeResized.png"));
  JLabel downPipe = new JLabel(new ImageIcon("fancyDownPipeResized.png"));

  // pipe checkers
  int upDifference = 0;
  int dpDifference = 0;
  boolean touchPipe;

  // counter for score
  static int count = 0;

  public MyFrame() {
    // setting up the frame
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(400, 800);
    this.setLocationRelativeTo(this);
    this.setLayout(null); 
    this.setVisible(true);
    this.setBackground(Color.black);
    this.addKeyListener(this);

    // setting up the pig
    int pigWidth = 100;
    int pigHeight = 100;
    pig.setSize(pigWidth, pigHeight);
    pig.setBounds(0, 0, pigWidth, pigHeight);
    this.add(pig);

    // adding pipe on the bottom half of the screen
    int upPipeWidth = 112;
    int upPipeHeight = 560;
    upPipe.setSize(upPipeWidth, upPipeHeight);
    upPipe.setBounds(300, 350, upPipeWidth, upPipeHeight);
    this.add(upPipe);

    // adding pipe on the top half of the screen
    int downPipeWidth = 112;
    int downPipeHeight = 560;
    downPipe.setSize(downPipeWidth, downPipeHeight);
    downPipe.setBounds(300, -350, downPipeWidth, downPipeHeight);
    this.add(downPipe);

    // add background
    background1.setSize(this.getWidth(), this.getHeight());
    background1.setBounds(0, 0, this.getWidth(), this.getHeight());
    this.add(background1);

    background2.setBounds(0, 0, this.getWidth(), this.getHeight());
    background2.setBackground(new Color(120, 196, 204, 255));
    background2.setOpaque(true);
    this.add(background2);

    System.out.println("The current High Score is: " + getHighScore());
    // timer that performs actions on pig
    int tickDelay = 40;
    Timer timer;
    ActionListener taskPerformer = new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        synchronized (MyFrame.this) {
          pig.setLocation(pig.getX(), pig.getY() + 3);
          checkBounds();
          movePipes();
        }
      }

    };
    timer = new Timer(tickDelay, taskPerformer);
    timer.start();
  }

  // makes the pig go up when space is pressed
  public void keyTyped(KeyEvent e) {
    synchronized (this) {
      switch (e.getKeyChar()) {
        case 32:
          pig.setLocation(pig.getX(), pig.getY() - 50);
          break;

      }
    }
  }

  // button to begin playing the game
  /*
   * Jbutton beginGame = new Jbutton("Start");
   * beginGame.setBackground(Color.YELLOW);
   * beginGame.setFont(new Font("Arial", 20));
   * beginGame.setLocation( , ); (how to set it to the center?)
   * beginGame.
   * 
   * 
   */

  // part of key class
  public void keyPressed(KeyEvent e) {
  }

  // part of key class
  public void keyReleased(KeyEvent e) {
  }

  // place to create graphics
  public void draw(Graphics g) {
  }

  // checks to see if pig touched the gruond
  public void checkBounds() {
    if (pig.getY() > this.getHeight() || pig.getY() < 0) {
      pig.setLocation(0, 0);
      System.out.println("Game Over, You touched the ground. Your final score was: " + count);
      System.exit(0);
    }

    while ((downPipe.getX() <= pig.getX()-5) && pig.getY() <= 160 + dpDifference) {
      touchPipe = true;
      System.out.println("Game Over, you touched the pipe. Your final score was: " + count);
      System.exit(0);

    }
    while ((upPipe.getX() <= pig.getX()-5) && pig.getY() >= 270 + upDifference) {
      touchPipe = true;
      System.out.println("Game Over, you touched the pipe. Your final score was: " + count);
      System.exit(0);
    }
    
  }

  private static final String REPLIT_DB_HIGHSCORE_KEY = "highScore";

  private int getHighScore() {
    String nullableHighScoreString = db.get(REPLIT_DB_HIGHSCORE_KEY);
    return nullableHighScoreString != null ? Integer.valueOf(nullableHighScoreString) : -1;
  }

  private void setHighScore(int highscore) {
    db.set(REPLIT_DB_HIGHSCORE_KEY, String.valueOf(highscore));
  }

  // randomly resets the pipe's position when the pig passes it
  public void movePipes() {
    int highScore = getHighScore(); // only get it once because it is slow

    // continously moves the pipe
    downPipe.setLocation(downPipe.getX() - 2, downPipe.getY());
    upPipe.setLocation(upPipe.getX() - 2, upPipe.getY());

    // changes score
    if (pig.getX() > downPipe.getX() + 120) {
      count++;
      if (count == highScore + 1) {
        System.out.println("Congrats, You beat the high score of " + highScore + "!");

      }
      if (count > highScore) {
        setHighScore(count);
      }
      System.out.println("Your current score is: " + count);
      
      int dpHeight = 0;
      int upHeight = 0;

      // randomly changes position
     
      int spacing = (int) (Math.random() * 50 + 580);
      while (dpHeight + spacing > upHeight || spacing < 550) {
        spacing = (int) (Math.random() * 50 + 550);
        dpHeight = (int) (Math.random() * 200 - 500);
        upHeight = (int) (Math.random() * 200 + 300);
      }

      // finds changes in position
      downPipe.setLocation(300, dpHeight);
      upPipe.setLocation(300, upHeight);
      upDifference = upHeight - 350;
      dpDifference = dpHeight + 350;

    }

  }
  
}
