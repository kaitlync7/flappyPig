
public class Main {
  public static void main(String[] args) {
    MyFrame test = new MyFrame();
  }

  // @Test
  // void addition() {
  //     assertEquals(2, 1 + 1);
  // }
}