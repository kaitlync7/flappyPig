import java.util.*;
import java.io.*;
import java.net.*;

public class ReplitDatabase {
  private static ReplitDatabase instance = null;

  private final String url;

  public ReplitDatabase() {
    if (instance != null) {
      throw new RuntimeException("Use getInstance() instead of new.");
    }

    instance = this;

    url = System.getenv("REPLIT_DB_URL");
  }

  public static ReplitDatabase getInstance() {
    return instance;
  }

  public void set(String key, String value) {
    try {
      URL url = new URL(this.url);
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setRequestMethod("POST");
      conn.setDoOutput(true);
      DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
      wr.writeBytes(key + "=" + value);
      wr.flush();
      wr.close();
      conn.getResponseCode();
    } catch (Exception e) {
      System.out.println("Failed to set key: " + key);
      e.printStackTrace();
    }
  }

  public String get(String key) {
    try {
      URL url = new URL(this.url + "/" + key);
      BufferedReader in = new BufferedReader(
      new InputStreamReader(url.openStream()));
      StringBuilder sb = new StringBuilder();
      String inputLine;
      while ((inputLine = in.readLine()) != null)
          sb.append(inputLine);
      in.close();
      return sb.toString();
    } catch (Exception e) {
      System.out.println("Failed to get key: " + key);
      e.printStackTrace();
      return null;
    }
  }
}